[{
    "name": "Sydney 悉尼",
    "description": "The app features exciting things to do, interactive maps, great food and wine and tips on customs and transport for Chinese travellers to Sydney. Available in 3 languages, English, simplified Chinese and Traditional Chinese.",
    "appleAppStrore": "https://itunes.apple.com/au/app/sydney-xi-ni/id559654518?mt=8",
    "googlePlay": "https://play.google.com/store/apps/details?id=com.sydney.dnswchina&feature=search_result#?t=W251bGwsMSwxLDEsImNvbS5zeWRuZXkuZG5zd2NoaW5hIl0",
    "imgPath": "http://www.destinationnsw.com.au/__data/assets/image/0009/148788/chinaIcon-72@2x.png"
}]